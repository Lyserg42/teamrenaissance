package com.upmc.gpotdevin.layout;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Paint;
import android.support.annotation.LayoutRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

/**
 * Created by gpotdevin on 26/09/2017.
 */

public class TodoAdapter extends ArrayAdapter<Todo> {

    final int layoutResource;
    private final List<Todo> todos;

    private static class ViewHolder {
        CheckBox checkBox;
        TextView textView;
        ImageView button;
    }


    public TodoAdapter(@NonNull Context context, @LayoutRes int resource, @NonNull List<Todo> objects) {
        super(context, resource, objects);
        layoutResource = resource;
        todos = objects;
    }

    @NonNull
    @Override
    public View getView(final int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        if (convertView == null){
            convertView = createView();
        }

        final Todo todo = getItem(position);
        ViewHolder holder = (ViewHolder)convertView.getTag();

        holder.textView.setText(todo.title);
        holder.textView.setPaintFlags(todo.checked ? Paint.STRIKE_THRU_TEXT_FLAG : 0);
        holder.textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showEditDialog(todo);
            }
        });


        holder.checkBox.setChecked(todo.checked);
        holder.checkBox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                todo.checked = !todo.checked;
                notifyDataSetChanged();
            }
        });

        holder.button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                todos.remove(position);
                notifyDataSetChanged();
            }
        });



        return convertView;
    }

    private View createView(){
        // Create item
        LayoutInflater inflater = LayoutInflater.from(getContext());
        View view = inflater.inflate(layoutResource, null);

        ViewHolder holder = new ViewHolder();
        holder.textView = view.findViewById(R.id.title);
        holder.checkBox = view.findViewById(R.id.checkbox);
        holder.button = view.findViewById(R.id.deleteBtn);

        view.setTag(holder);
        return view;
    }

    private void showEditDialog(final Todo todo){
        final EditText et = new EditText(getContext());
        et.setText(todo.title);

        new AlertDialog.Builder(getContext())
                .setTitle("Edit item")
                .setView(et)
                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        todo.title = et.getText().toString();
                        notifyDataSetChanged();
                    }
                })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                    }
                })
                .show();
    }
}
