package com.upmc.gpotdevin.layout;

/**
 * Created by gpotdevin on 26/09/2017.
 */

public class Todo {
    public String title;
    public boolean checked;

    Todo(String title){
        this.title = title;
        checked = false;
    }
}
