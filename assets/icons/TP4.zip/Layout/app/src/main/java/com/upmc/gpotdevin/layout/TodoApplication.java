package com.upmc.gpotdevin.layout;

import android.app.Application;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gregory on 24/10/2017.
 */

public class TodoApplication extends Application {
    private List<Todo> todos;

    @Override
    public void onCreate() {
        super.onCreate();

        todos = new ArrayList<>();
        todos.add(new Todo("First item"));
        todos.add(new Todo("Second item"));
        todos.add(new Todo("Third item"));
    }

    public List<Todo> getTodos() {
        return todos;
    }
}
